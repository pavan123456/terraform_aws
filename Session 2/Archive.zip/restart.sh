#!/bin/bash
/opt/bitnami/apache-tomcat/bin/shutdown.sh
/opt/bitnami/apache-tomcat/bin/startup.sh

