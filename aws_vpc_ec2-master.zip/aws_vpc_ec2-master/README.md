# AWS VPC and EC2 Reference Architecture Implementation with Terraform
AWS Reference Architecture for VPC and EC2

![AWS VPC and EC2 Reference Architecture](https://niyazierdogan.files.wordpress.com/2018/12/terraform-aws-vpc-and-ec2-architecture.png)
